package com.widgetmaker.app;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Collections;
import java.util.List;

public class TileConfigActivity extends Activity {
    int wid;
    String pkg;
    int color = U.COLORS[0];
    EditText label;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setResult(RESULT_CANCELED);
        wid = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }
        SharedPreferences p = U.p(this);
        pkg = p.getString("pkg_" + wid, null);
        color = p.getInt("color_" + wid, color);

        final PackageManager pm = getPackageManager();
        Intent mi = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        final List<ResolveInfo> apps = pm.queryIntentActivities(mi, 0);
        Collections.sort(apps, (x, y) -> x.loadLabel(pm).toString().compareToIgnoreCase(y.loadLabel(pm).toString()));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pd = U.dp(this, 16);
        root.setPadding(pd, pd + U.dp(this, 24), pd, pd);
        TextView t = new TextView(this);
        t.setText("1. Name and colour   2. Tap an app   3. Save");
        t.setTextSize(16);
        root.addView(t);
        label = new EditText(this);
        label.setHint("Widget name");
        label.setText(p.getString("label_" + wid, ""));
        root.addView(label);
        root.addView(U.swatches(this, color, cc -> color = cc));
        Button save = new Button(this);
        save.setText("Save widget");
        root.addView(save);

        ListView lv = new ListView(this);
        lv.setAdapter(new BaseAdapter() {
            public int getCount() { return apps.size(); }
            public Object getItem(int i) { return apps.get(i); }
            public long getItemId(int i) { return i; }
            public View getView(int i, View v, ViewGroup g) {
                TileConfigActivity a = TileConfigActivity.this;
                ResolveInfo ri = apps.get(i);
                LinearLayout r = new LinearLayout(a);
                r.setGravity(Gravity.CENTER_VERTICAL);
                r.setPadding(0, U.dp(a, 6), 0, U.dp(a, 6));
                ImageView iv = new ImageView(a);
                iv.setImageBitmap(U.bmp(ri.loadIcon(pm)));
                r.addView(iv, new LinearLayout.LayoutParams(U.dp(a, 40), U.dp(a, 40)));
                TextView tv = new TextView(a);
                tv.setText(ri.loadLabel(pm));
                tv.setTextSize(16);
                tv.setPadding(U.dp(a, 12), 0, 0, 0);
                r.addView(tv);
                return r;
            }
        });
        lv.setOnItemClickListener((a, v, i, id) -> {
            pkg = apps.get(i).activityInfo.packageName;
            label.setText(apps.get(i).loadLabel(pm));
            Toast.makeText(this, "Selected: " + apps.get(i).loadLabel(pm), Toast.LENGTH_SHORT).show();
        });
        root.addView(lv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        setContentView(root);

        save.setOnClickListener(v -> {
            if (pkg == null) { Toast.makeText(this, "Pick an app first", Toast.LENGTH_SHORT).show(); return; }
            String l = label.getText().toString().trim();
            if (l.isEmpty()) l = pkg;
            U.p(this).edit().putString("pkg_" + wid, pkg).putString("label_" + wid, l).putInt("color_" + wid, color).apply();
            TileWidget.update(this, AppWidgetManager.getInstance(this), wid);
            Intent r = new Intent();
            r.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid);
            setResult(RESULT_OK, r);
            finish();
        });
    }
}
