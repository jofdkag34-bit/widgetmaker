package com.widgetmaker.app;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        TextView t = new TextView(this);
        int pd = U.dp(this, 20);
        t.setPadding(pd, pd + U.dp(this, 28), pd, pd);
        t.setTextSize(17);
        t.setText("Widget Maker\n\n"
            + "How to add a widget:\n"
            + "1. Press and hold an empty spot on your home screen.\n"
            + "2. Tap Widgets.\n"
            + "3. Find Widget Maker and drag one to the screen:\n\n"
            + "App Tile - a button that opens any app you choose, with your own name and colour. Use it for apps that have no widget.\n\n"
            + "Info Card - big clock, date, battery and a short note. Tap it to refresh the battery.\n\n"
            + "After you drop a widget, pick the app or colour and tap Save. To change a widget later, remove it and add it again.");
        ScrollView sv = new ScrollView(this);
        sv.addView(t);
        setContentView(sv);
    }
}
