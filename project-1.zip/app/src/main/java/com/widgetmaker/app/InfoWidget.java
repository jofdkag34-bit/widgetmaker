package com.widgetmaker.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.widget.RemoteViews;

public class InfoWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) update(c, m, id);
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        SharedPreferences.Editor e = U.p(c).edit();
        for (int id : ids) e.remove("note_" + id).remove("color_" + id);
        e.apply();
    }

    static void update(Context c, AppWidgetManager m, int id) {
        SharedPreferences p = U.p(c);
        int color = p.getInt("color_" + id, U.COLORS[0]);
        String note = p.getString("note_" + id, "");
        int tc = U.textOn(color);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_info);
        U.bg(rv, R.id.bg, color);
        for (int v : new int[]{R.id.time, R.id.date, R.id.batt, R.id.note}) rv.setTextColor(v, tc);
        Intent bi = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        String batt = "Battery --";
        if (bi != null) {
            int lvl = bi.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int sc = bi.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            if (lvl >= 0 && sc > 0) batt = "Battery " + (lvl * 100 / sc) + "%";
        }
        rv.setTextViewText(R.id.batt, batt);
        rv.setTextViewText(R.id.note, note);
        Intent r = new Intent(c, InfoWidget.class);
        r.setAction(AppWidgetManager.ACTION_APPWIDGET_UPDATE);
        r.putExtra(AppWidgetManager.EXTRA_APPWIDGET_IDS, new int[]{id});
        rv.setOnClickPendingIntent(R.id.root, PendingIntent.getBroadcast(c, id, r, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT));
        m.updateAppWidget(id, rv);
    }
}
