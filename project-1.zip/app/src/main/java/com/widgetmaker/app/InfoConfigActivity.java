package com.widgetmaker.app;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class InfoConfigActivity extends Activity {
    int wid;
    int color = U.COLORS[0];

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        setResult(RESULT_CANCELED);
        wid = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID);
        if (wid == AppWidgetManager.INVALID_APPWIDGET_ID) { finish(); return; }
        SharedPreferences p = U.p(this);
        color = p.getInt("color_" + wid, color);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int pd = U.dp(this, 16);
        root.setPadding(pd, pd + U.dp(this, 24), pd, pd);
        TextView t = new TextView(this);
        t.setText("Info card: time, date, battery and your note");
        t.setTextSize(16);
        root.addView(t);
        final EditText note = new EditText(this);
        note.setHint("Note (optional)");
        note.setText(p.getString("note_" + wid, ""));
        root.addView(note);
        root.addView(U.swatches(this, color, cc -> color = cc));
        Button save = new Button(this);
        save.setText("Save widget");
        root.addView(save);
        setContentView(root);
        save.setOnClickListener(v -> {
            U.p(this).edit().putString("note_" + wid, note.getText().toString().trim()).putInt("color_" + wid, color).apply();
            InfoWidget.update(this, AppWidgetManager.getInstance(this), wid);
            Intent r = new Intent();
            r.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, wid);
            setResult(RESULT_OK, r);
            finish();
        });
    }
}
