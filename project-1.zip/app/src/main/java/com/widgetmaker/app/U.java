package com.widgetmaker.app;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.RemoteViews;

final class U {
    static final int[] COLORS = {0xFF1E1E2E, 0xFFFF5D8F, 0xFF7FD4FF, 0xFF4ADE80, 0xFFFBBF24, 0xFFA78BFA, 0xFFF97316, 0xFFFFFFFF};
    interface Pick { void on(int color); }

    static SharedPreferences p(Context c) { return c.getSharedPreferences("w", Context.MODE_PRIVATE); }
    static int dp(Context c, int v) { return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, c.getResources().getDisplayMetrics()); }
    static int textOn(int bg) {
        double l = (0.299 * Color.red(bg) + 0.587 * Color.green(bg) + 0.114 * Color.blue(bg)) / 255;
        return l > 0.6 ? 0xFF111111 : 0xFFFFFFFF;
    }
    static Bitmap bmp(Drawable d) {
        int s = 128;
        Bitmap b = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        d.setBounds(0, 0, s, s);
        d.draw(cv);
        return b;
    }
    static void bg(RemoteViews rv, int id, int color) { rv.setInt(id, "setColorFilter", color); }

    static View swatches(final Context c, int sel, final Pick pick) {
        HorizontalScrollView sv = new HorizontalScrollView(c);
        LinearLayout row = new LinearLayout(c);
        sv.addView(row);
        final View[] vs = new View[COLORS.length];
        for (int i = 0; i < COLORS.length; i++) {
            final int col = COLORS[i];
            View v = new View(c);
            GradientDrawable g = new GradientDrawable();
            g.setShape(GradientDrawable.OVAL);
            g.setColor(col);
            g.setStroke(dp(c, 2), 0xFF888888);
            v.setBackground(g);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(c, 40), dp(c, 40));
            lp.setMargins(dp(c, 6), dp(c, 6), dp(c, 6), dp(c, 6));
            row.addView(v, lp);
            vs[i] = v;
            v.setAlpha(col == sel ? 1f : 0.45f);
            v.setOnClickListener(x -> {
                for (int j = 0; j < vs.length; j++) vs[j].setAlpha(COLORS[j] == col ? 1f : 0.45f);
                pick.on(col);
            });
        }
        return sv;
    }
}
