package com.widgetmaker.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class TileWidget extends AppWidgetProvider {
    @Override
    public void onUpdate(Context c, AppWidgetManager m, int[] ids) {
        for (int id : ids) update(c, m, id);
    }

    @Override
    public void onDeleted(Context c, int[] ids) {
        SharedPreferences.Editor e = U.p(c).edit();
        for (int id : ids) e.remove("pkg_" + id).remove("label_" + id).remove("color_" + id);
        e.apply();
    }

    static void update(Context c, AppWidgetManager m, int id) {
        SharedPreferences p = U.p(c);
        String pkg = p.getString("pkg_" + id, null);
        String label = p.getString("label_" + id, "Tap to set up");
        int color = p.getInt("color_" + id, U.COLORS[0]);
        RemoteViews rv = new RemoteViews(c.getPackageName(), R.layout.widget_tile);
        U.bg(rv, R.id.bg, color);
        rv.setTextViewText(R.id.label, label);
        rv.setTextColor(R.id.label, U.textOn(color));
        PendingIntent pi = null;
        int flags = PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT;
        if (pkg != null) {
            try { rv.setImageViewBitmap(R.id.icon, U.bmp(c.getPackageManager().getApplicationIcon(pkg))); } catch (Exception ignored) { }
            Intent li = c.getPackageManager().getLaunchIntentForPackage(pkg);
            if (li != null) pi = PendingIntent.getActivity(c, id, li, flags);
        }
        if (pi == null) {
            Intent ci = new Intent(c, TileConfigActivity.class);
            ci.setAction("cfg" + id);
            ci.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id);
            pi = PendingIntent.getActivity(c, id, ci, flags);
        }
        rv.setOnClickPendingIntent(R.id.root, pi);
        m.updateAppWidget(id, rv);
    }
}
